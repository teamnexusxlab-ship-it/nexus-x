NEXUS-X — Prototype PWA + recherche SerpApi
============================================

CONTENU
- index.html : page d'accueil et interface de recherche.
- manifest.json : configuration de l'application installable.
- service-worker.js : cache de base pour certaines ressources.
- netlify/functions/search.mjs : fonction serveur qui appelle SerpApi.
- netlify.toml : configuration Netlify.
- icons/ : icônes PWA.

IMPORTANT
1. Le fichier HTML ne contient pas votre clé SerpApi.
2. Le site doit être déployé sur Netlify (HTTPS) pour tester le service worker et l'installation PWA.
3. La recherche réelle ne fonctionnera qu'après configuration de la variable d'environnement SERPAPI_KEY dans Netlify.
4. Ne partagez jamais votre clé API dans le code public, dans une capture d'écran ou dans le chat.
5. L'interface de démonstration n'affiche pas de vrais produits ni de prix : elle sert uniquement à tester le design.
6. Le bouton « Installer » dépend des critères de Chrome/Android. S'il n'apparaît pas, ouvrez le menu ⋮ de Chrome et vérifiez « Installer l'application » ou « Ajouter à l'écran d'accueil ».

DÉPLOIEMENT NETLIFY
1. Décompressez le ZIP en gardant la structure des dossiers.
2. Dans Netlify, créez un nouveau site depuis un déploiement manuel en déposant le dossier du site, ou importez le projet depuis un dépôt Git.
   Remarque : les fonctions Netlify sont plus fiables avec un déploiement de projet qui inclut la structure du dépôt. Si le glisser-déposer manuel ne construit pas la fonction, utilisez un dépôt Git ou l'interface de déploiement Netlify qui prend en charge les fonctions.
3. Dans les paramètres du site, allez à Environment variables.
4. Ajoutez SERPAPI_KEY et collez la clé SerpApi dans le champ de valeur. Ne la mettez jamais dans index.html.
5. Redéployez le site.
6. Testez une recherche, par exemple « ordinateur portable ».
7. Visitez le site en HTTPS, puis utilisez le bouton Installer ou le menu ⋮ de Chrome.

TESTS CONSEILLÉS
- « ordinateur portable »
- « intelligence artificielle »
- « technologie »
- « voyages »

LIMITES
- SerpApi impose les limites du plan de votre compte; cette architecture ne fournit pas un quota illimité.
- Le service peut renvoyer des erreurs si la clé est incorrecte ou si le quota est épuisé.
- Ce prototype n'inclut pas encore de connexion propriétaire, de tableau de bord financier, ni de liens d'affiliation.
