export default async (request) => {
  const url = new URL(request.url);
  const q = (url.searchParams.get("q") || "").trim();

  if (!q) {
    return Response.json({ error: "Un terme de recherche est requis." }, { status: 400 });
  }
  if (q.length > 250) {
    return Response.json({ error: "La recherche est trop longue." }, { status: 400 });
  }

  const apiKey = process.env.SERPAPI_KEY;
  if (!apiKey) {
    return Response.json({
      error: "SERPAPI_KEY n'est pas configurée dans les variables d'environnement Netlify."
    }, { status: 503 });
  }

  try {
    const params = new URLSearchParams({
      engine: "google",
      q,
      api_key: apiKey
    });
    const apiResponse = await fetch(`https://serpapi.com/search.json?${params.toString()}`, {
      headers: { "Accept": "application/json" },
      signal: AbortSignal.timeout(15000)
    });
    const payload = await apiResponse.json();

    if (!apiResponse.ok || payload.error) {
      return Response.json({
        error: payload.error || "Le fournisseur de recherche a renvoyé une erreur."
      }, { status: 502 });
    }

    const results = (payload.organic_results || []).slice(0, 10).map(item => ({
      title: item.title || "",
      link: item.link || "",
      displayed_link: item.displayed_link || "",
      snippet: item.snippet || ""
    })).filter(item => item.link);

    return Response.json({ query: q, results }, {
      headers: {
        "Cache-Control": "public, max-age=60, s-maxage=60",
        "X-Content-Type-Options": "nosniff"
      }
    });
  } catch (error) {
    return Response.json({ error: "Impossible de contacter le service de recherche. Réessayez plus tard." }, { status: 502 });
  }
};
